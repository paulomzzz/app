package com.example.myapplication.model

import kotlinx.serialization.Serializable

@Serializable //el serializable es la comunnicacion de json a clase y de clase a json
data class Post(
    val userId: Int,
    val id: Int? = null,
    val title: String,
    val body: String
)