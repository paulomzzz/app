package com.example.myapplication.view

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myapplication.controller.CrearPostViewModel


@Composable
fun PostView() {
    val viewModel: CrearPostViewModel = viewModel()
    val state by viewModel.state.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = "Crear Post", style = MaterialTheme.typography.titleLarge)

        OutlinedTextField(
            value = state.title,
            onValueChange = { viewModel.onTitleChange(value = it) },
            label = { Text("Título") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = state.body,
            onValueChange = { viewModel.onBodyChange(valor = it) },
            label = { Text("Contenido") },
            minLines = 4,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp)
        )

        Button(
            onClick = { viewModel. },
            enabled = !state.isCreating && state.title.isNotBlank() && state.body.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (state.isCreating) "Enviando..." else "Crear")
        }

        // Loading
        if (state.isCreating) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(modifier = Modifier.size(28.dp))
            }
        }

        // Error
        state.createError?.let { msg ->
            AssistChipError(texto = msg, onDismiss = {  })
        }

        // Resultado
        state.created?.let { post ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Creado correctamente", style = MaterialTheme.typography.titleMedium)
                    Text("ID: ${post.id ?: "(sin id)"}")
                    Text("Title: ${post.title}")
                    Text("Body: ${post.body}")
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = {  }) { Text("Limpiar") }
                }
            }
        }

        // Lista de posts
        Text("Posts", style = MaterialTheme.typography.titleMedium)
        if (state.isListLoading && state.list.isEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) { CircularProgressIndicator(modifier = Modifier.size(28.dp)) }
        } else if (state.listError != null) {
            ErrorBanner(texto = state.listError ?: "Error", onDismiss = {  })
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(state.list, key = { it.id ?: (it.title + it.body).hashCode() }) { p ->
                    Card {
                        Column(Modifier.padding(12.dp)) {
                            Text(p.title, style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(4.dp))
                            Text(p.body, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ErrorBanner(texto: String, onDismiss: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        contentColor = MaterialTheme.colorScheme.onErrorContainer,
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(texto, modifier = Modifier.weight(1f))
            TextButton(onClick = onDismiss) { Text("Cerrar") }
        }
    }
}

@Composable
private fun AssistChipError(texto: String, onDismiss: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        contentColor = MaterialTheme.colorScheme.onErrorContainer,
        tonalElevation = 2.dp,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(texto, modifier = Modifier.weight(1f))
            TextButton(onClick = onDismiss) { Text("Cerrar") }
        }
    }
}
