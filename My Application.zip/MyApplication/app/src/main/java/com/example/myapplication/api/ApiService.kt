package com.example.myapplication.api

import com.example.myapplication.model.Post
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST

interface ApiService { //definiciones que se comuinican con la api por que no es consumible por si sola para eso aparece el rerytpfit

    @Headers("Content-Type: application/json")
    @POST("posts")
    suspend fun crearPost(@Body body: Post): Post

    @GET("posts")
    suspend fun obtenerPost(): List<Post>
}