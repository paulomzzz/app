package com.example.myapplication.controller

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.api.ApiService
import com.example.myapplication.model.Post
import com.example.myapplication.network.RetrofitProvider
import kotlinx.coroutines.Delay
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CrearPostUiState(
    // creación
    val title: String = "",
    val body: String = "",
    val isCreating: Boolean = false,
    val created: Post? = null,
    val createError: String? = null,
    // listado
    val list: List<Post> = emptyList(),
    val isListLoading: Boolean = false,
    val listError: String? = null
)

class CrearPostViewModel() : ViewModel() {

    private val api: ApiService by lazy { RetrofitProvider.create<ApiService>() }
    private val _state = MutableStateFlow(CrearPostUiState())
    val state: StateFlow<CrearPostUiState> = _state.asStateFlow()

    init {
        cargarPosts()
    }

    fun onTitleChange(value: String) {
        _state.update { it.copy(title = value, createError = null) }
    }

    fun onBodyChange(valor: String) {
        _state.update { it.copy(body = valor) }
    }


    fun cargarPosts() {
        viewModelScope.launch {
            _state.update { it.copy(isListLoading = true, listError = null) }
            flow { emit(api.obtenerPost()) }
                .onEach { posts -> _state.update { it.copy(list = posts, isListLoading = false) } }
                .catch { e ->
                    _state.update {
                        it.copy(
                            isListLoading = false,
                            listError = e.message
                        )
                    }
                }
                .collect()
        }
    }

    fun crearPost(){
        viewModelScope.launch {
            val post = state.value
            if(post.title.isBlank() || post.body.isBlank()){
                _state.update { it.copy() }
            }
        }
    }
}

